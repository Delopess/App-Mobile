// Feito por Denisson Lopes ADS 23/02
// Docente: Vinicius Gorgonho

package br.com.senaimt.alcoolgasapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText campoAlcool, campoGasolina;
    private Button calculateBtn;
    private TextView labelResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar componentes
        campoAlcool = findViewById(R.id.campo_alcool);
        campoGasolina = findViewById(R.id.campo_gas);
        calculateBtn = findViewById(R.id.calculatebtn);
        labelResult = findViewById(R.id.label_result);

        // Configurar listener do botão
        calculateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Efeito de clique
                v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100)
                        .withEndAction(new Runnable() {
                            @Override
                            public void run() {
                                v.animate().scaleX(1f).scaleY(1f).setDuration(100);
                                calcularMelhorOpcao();
                            }
                        }).start();
            }
        });
    }

    private void calcularMelhorOpcao() {
        // Obter valores dos campos
        String alcoolStr = campoAlcool.getText().toString();
        String gasolinaStr = campoGasolina.getText().toString();

        // Verificar se os campos estão preenchidos
        if (alcoolStr.isEmpty() || gasolinaStr.isEmpty()) {
            labelResult.setText("Preencha ambos os valores");
            return;
        }

        try {
            // Converter para números
            double precoAlcool = Double.parseDouble(alcoolStr);
            double precoGasolina = Double.parseDouble(gasolinaStr);

            // Verificar se os valores são válidos
            if (precoAlcool <= 0 || precoGasolina <= 0) {
                labelResult.setText("Valores devem ser maiores que zero");
                return;
            }

            // Calcular proporção
            double proporcao = precoAlcool / precoGasolina;

            // Determinar melhor opção
            if (proporcao < 0.7) {
                labelResult.setText("É mais vantajoso abastecer com Álcool");
            } else {
                labelResult.setText("É mais vantajoso abastecer com Gasolina");
            }

        } catch (NumberFormatException e) {
            labelResult.setText("Digite valores numéricos válidos");
        }
    }
}