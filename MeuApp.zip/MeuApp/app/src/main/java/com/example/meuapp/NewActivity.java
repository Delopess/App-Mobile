package com.example.meuapp;
import android.widget.ArrayAdapter;

import android.os.Bundle;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class NewActivity extends AppCompatActivity {
    // QUEM TEM OS DADOS PARA EXIBIR
    private ArrayList<String> listaContato;
    // ADAPTADOR DA LISTA PARA EXIBIR
    private ArrayAdapter<String> adaptador;
    // lAYOUT DA LINHA DA LISTA
    private int adaptadorLayout = android.R.layout.simple_list_item_1;
    // Lista do layout
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);
        listView = findViewById(R.id.lista_view);
        // preenche a lista
        listaContato = new ArrayList<>();
        listaContato.add("João");
        listaContato.add("Maria");
        listaContato.add("José");
        // Preenche o adaptador com os dados e o layout da linha
        adaptador = new ArrayAdapter<>(this, adaptadorLayout, listaContato);
        // PASSA O ADAPTADOR PARA TELA
        listView.setAdapter(adaptador);

    }
}