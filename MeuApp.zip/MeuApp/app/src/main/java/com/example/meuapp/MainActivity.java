package com.example.meuapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView labelNome;
    EditText campoNome;
    TextView labelTelefone;
    EditText campoTelefone;
    TextView labelEmail;
    EditText campoEmail;
    Button btnCadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Recupera o componente da memoria.
        campoNome = findViewById(R.id.campo_nome);

        campoTelefone = findViewById(R.id.campo_telefone);

        campoEmail = findViewById(R.id.campo_email);

        btnCadastrar = findViewById(R.id.btnCadastrar);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Cadastrado com sucesso", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                String nome = campoNome.getText().toString();
                intent.putExtra("nome", nome);
                startActivity(intent);
            }
        });


    }
}